touch tests//.timeout
CMD="   /home/roberlks222/Documentos/Clase/MP/MP2223/Language0/dist/Debug/GNU-Linux/language0  < data/SimpleText.txt 1> tests//.out5 2>&1"
eval $CMD
rm tests//.timeout
